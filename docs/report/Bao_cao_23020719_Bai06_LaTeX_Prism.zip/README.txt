Bao cao Bai 06 - Do Viet Anh, 23020719
Mo main.tex trong Prism. Bien dich bang XeLaTeX hoac pdfLaTeX.
Cac hinh nam trong figures/. Sua lien ket tai \github va \drive.
