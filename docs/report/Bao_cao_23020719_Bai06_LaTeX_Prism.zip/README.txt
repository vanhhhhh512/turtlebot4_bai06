Đỗ Việt Anh — MSSV 23020719 — Bài thực hành 06

Giải nén toàn bộ ZIP, mở main.tex trong Prism và biên dịch.
Giữ các thư mục hình và file vietnamese-unicode.tex cạnh main.tex.
Bản báo cáo có 13 trang, 15 hình; số liệu chuyển động từ Gazebo thật với đầu vào nhãn thử.
Ảnh robot là ảnh Gazebo; các hình sáu cử chỉ là sơ đồ minh họa.
